This prepends the beginning of each line with "//":

`:%s!^!//!`

It follows then that this appends to the end of the line

`:%s!$!//!`