  - first village with mine - 76 69 124
  - village + temple + nether portal - 1265 68 2832
  - desert village + temple - -4405 70 -4957

#### BASE 1

`large home, horse and extensive gardens -713 72 3259`

  - mine -146 73 3226

Damo's mine: -128 26 3238