`diff -rq --exclude=.svn dir1 dir2`

recursively (-r) diffs a directory, listing files only (-q) and
excluding any files with .svn in the path (ie. subversion directories)