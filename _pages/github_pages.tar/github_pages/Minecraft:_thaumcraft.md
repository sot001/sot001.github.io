  - crucible - move it outside and put into the ground

` I                =U=`
`=O=  <- top view   *   <- bottom view`
` I`

  - thaumium - use mosstones and iron. let flux go itself.
  - collect mana beans for esssentia
  - research / build arcane furnace and arcane alembic to distill
    essentia. extract into vials and then use that in the crucible
  - research wand of equal trade.
    <http://thaumcraft-3.wikia.com/wiki/Wand_of_Equal_Trade> for
    collecting obsidian