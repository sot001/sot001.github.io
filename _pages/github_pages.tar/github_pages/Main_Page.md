[category: Index](category:_Index "wikilink")

[ansible](ansible "wikilink")

[Audio](Audio "wikilink")

[AWS](AWS "wikilink")

[Bash](Bash "wikilink")

[Centos 7](Centos_7 "wikilink")

[Docker](Docker "wikilink")

[e2guardian](e2guardian "wikilink")

[GCP](GCP "wikilink")

[Git](Git "wikilink")

[gmail](gmail "wikilink")

[firefox containers](firefox_containers "wikilink")

[iRedMail](iRedMail "wikilink")

[keybase / gpg](keybase_/_gpg "wikilink")

[Linux generally](Linux_generally "wikilink")

[logitechmediaserver](logitechmediaserver "wikilink")

[MineCraft](MineCraft "wikilink")

[Mysql](Mysql "wikilink")

[Mythtv](Mythtv "wikilink")

[Nagios](Nagios "wikilink")

[Network](Network "wikilink")

[NextCloud](NextCloud "wikilink")

[OpenVPN](OpenVPN "wikilink")

[Perl](Perl "wikilink")

[Python](Python "wikilink")

[Recipes](Recipes "wikilink")

[Ruby](Ruby "wikilink")

[Sql server](Sql_server "wikilink")

[squid](squid "wikilink")

[Ssh](Ssh "wikilink")

[terraform](terraform "wikilink")

[transmission](transmission "wikilink")

[Ubuntu](Ubuntu "wikilink")

[Vi](Vi "wikilink")

[Video](Video "wikilink")

[Windows 7](Windows_7 "wikilink")

## Getting started

  - [Configuration settings
    list](http://www.mediawiki.org/wiki/Manual:Configuration_settings)
  - for tips on editing, go
    [here](http://meta.wikimedia.org/wiki/Help:Contents#For_editors)
  - to convert from HTML to wiki, use
    [this](https://tools.wmflabs.org/magnustools/html2wiki.php) page
  - to convert excel to wiki, use
    [this](http://excel2wiki.net/index.php) page
  - to add new links to the sidebar navigation, edit this page;
    [MediaWiki:Sidebar](MediaWiki:Sidebar "wikilink")
  - use link in 'Toolbox' navigation bar on left to upload a file, or
    simply press 'alt + shift + u'