scripts etc here;

`/usr/local/share/e2guardian/scripts`

install files here

`/usr/local/e2guardian/`