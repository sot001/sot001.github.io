  - sausages wrapped in pastry
  - baked potatoes prefilled with cheese, bacon and parsely or tuna,
    wrapped in alfoil to keep warm
  - tea in thermos