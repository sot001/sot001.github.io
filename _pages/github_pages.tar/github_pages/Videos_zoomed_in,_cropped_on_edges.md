check the fill settings in mythvideo. Menu -\> video -\> fill

if its set to fill, then unset the default by going into the
mythfrontend video settings page.