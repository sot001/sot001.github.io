Following the instructions on the top post
[here](http://www.iredmail.org/forum/topic2736-iredmail-support-create-blackhole-mail-address-eg-noreplyexamplecom.html)
didn't entirely work for me, so this is what did;

1\. created a 'blackhole' email account with password

2\. logged in to blackhole email account and created filter to delete
all mail

3\. inserted entry into vmail.alias to forward email from unwanted
address to blackhole account