`dvgrab -rewind -autosplit -timestamp`

will create a file like: dvgrab-2010.11.12_20-23-46.m2t

`dvgrab -rewind -autosplit -timestamp -format=hdv -srt foo-`

will create files prepended with 'foo-' and pulls HDV format