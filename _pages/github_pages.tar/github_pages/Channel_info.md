the serviceid in the channel table is the same as the SID on
[this](http://www.bbc.co.uk/reception/info/sat_frequencies.shtml) page.
could be best to reshuffle channel stuff