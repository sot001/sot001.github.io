    arp -n

shows cached macs