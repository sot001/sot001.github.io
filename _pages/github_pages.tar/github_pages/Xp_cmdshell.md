  - [what account is xp_cmdshell running
    as](what_account_is_xp_cmdshell_running_as "wikilink")