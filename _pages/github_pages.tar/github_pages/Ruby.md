  - [| install cheatsheet](http://cheat.errtheblog.com/s/rvm) - worked
    on Centos 6