  - [extract audio from video and
    tag](extract_audio_from_video_and_tag "wikilink")
  - [Ffmpeg](Ffmpeg "wikilink")