  - spawners under haybales. build a diamond dolly and move one to use
    as a spawner
  - apothecary to buy witchery stuff

<!-- end list -->

    fml-server-3.log:[12:26:09] [Server thread/INFO] [OpenMods/]: openblocks.common.PlayerInventoryStore.onPlayerDeath(PlayerInventoryStore.java:303): Storing post-mortem inventory into /home/minecraft/ftb/./world/data/inventory-CursedSpirit-2016-01-30_12.26.09-death-0.dat. It can be restored with command '/ob_inventory restore CursedSpirit CursedSpirit-2016-01-30_12.26.09-death-0'

`/gamerule KeepInventory true`