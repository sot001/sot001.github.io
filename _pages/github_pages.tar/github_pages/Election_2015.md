  - Conservative Party –
    <https://s3-eu-west-1.amazonaws.com/manifesto2015/ConservativeManifesto2015.pdf>
  - The Green Party –
    <https://www.greenparty.org.uk/assets/files/manifesto/Green_Party_2015_General_Election_Manifesto_Searchable.pdf>
  - Labour Party –
    <http://www.labour.org.uk/page/-/BritainCanBeBetter-TheLabourPartyManifesto2015.pdf>
  - Liberal Democrats –
    <https://d3n8a8pro7vhmx.cloudfront.net/libdems/pages/8907/attachments/original/1429028133/Liberal_Democrat_General_Election_Manifesto_2015.pdf?1429028133>
  - Plaid Cymru –
    <https://www.partyof.wales/uploads/Plaid_Cymru_2015_Westminster_Manifesto.pdf>
  - SNP – <http://votesnp.com/docs/manifesto.pdf>
  - UKIP –
    <https://d3n8a8pro7vhmx.cloudfront.net/ukipdev/pages/1103/attachments/original/1429295050/UKIPManifesto2015.pdf?1429295050>