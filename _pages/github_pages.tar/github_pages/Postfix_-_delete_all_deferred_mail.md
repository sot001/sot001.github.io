[category: postfix](category:_postfix "wikilink") [category:
email](category:_email "wikilink")

Good for when google defer's email due to loads of spam coming through

`postsuper -d ALL deferred`