to see what hosts are on your network;

`nmap -sP 192.168.1.1/24 - shows ips & MAC via ping`
`nmap -O 192.168.1.1/24 - show operating systems`
`nmap -sS 192.168.1.1/24 - shows which ports are open`