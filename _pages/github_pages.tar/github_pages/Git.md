[category: git](category:_git "wikilink")

![<File:https://imgs.xkcd.com/comics/git.png>](https:/imgs.xkcd.com/comics/git.png
"File:https://imgs.xkcd.com/comics/git.png")

Ref: <http://xkcd.com/1597/>

Git documentation can be found [here](http://git-scm.com/book/en/v2)

  - [GitLab: troubleshooting](GitLab:_troubleshooting "wikilink")
  - [git: helpful commands](git:_helpful_commands "wikilink")
  - [git: split out subdirectory to new
    repository](git:_split_out_subdirectory_to_new_repository "wikilink")
  - [git: branching](git:_branching "wikilink") - split into a new dev
    branch leaving master untouched
  - [git: troubleshooting](git:_troubleshooting "wikilink")
  - [git prompt](git_prompt "wikilink")