use mutt;

`mutt -a ./file.ovpn -s "openvpn file" -- someone@example.com`