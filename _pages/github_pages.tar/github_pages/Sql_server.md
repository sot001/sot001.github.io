  - [email expiring passwords](email_expiring_passwords "wikilink")
  - [return comma separated
    list](return_comma_separated_list "wikilink")
  - [Returning a comma-delimited list of
    values](Returning_a_comma-delimited_list_of_values "wikilink") -
    alternate solution
  - [networkdays function](networkdays_function "wikilink")
  - [Xp cmdshell](Xp_cmdshell "wikilink")
  - [update field with
    auto-increment](update_field_with_auto-increment "wikilink")
  - [rebuild those indexes that need
    it](rebuild_those_indexes_that_need_it "wikilink")