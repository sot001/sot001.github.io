stuff related to bash shells here

  - [manipulating strings](manipulating_strings "wikilink")
  - [progress bar while waiting](progress_bar_while_waiting "wikilink")
  - [AWK](AWK "wikilink")
  - [grep](grep "wikilink")
  - [sed](sed "wikilink")
  - [find a pattern in a string](find_a_pattern_in_a_string "wikilink")
  - [diff](diff "wikilink")
  - [sending file attachments from command
    line](sending_file_attachments_from_command_line "wikilink")
  - [recursively create
    directories](recursively_create_directories "wikilink")
  - [show true working
    directory](show_true_working_directory "wikilink")
  - [set sticky bit](set_sticky_bit "wikilink")
  - [inherit parent permissions](inherit_parent_permissions "wikilink")
  - [Nmap](Nmap "wikilink")
  - [Vi](Vi "wikilink")
  - [get filename without leading
    dirs](get_filename_without_leading_dirs "wikilink")
  - [forward X11 through two
    hosts](forward_X11_through_two_hosts "wikilink")
  - [loops](loops "wikilink")
  - [script options](script_options "wikilink")
  - [RegExp](RegExp "wikilink")
  - [crap colors in bash](crap_colors_in_bash "wikilink")
  - [kill zombie procs](kill_zombie_procs "wikilink")
  - [heredoc](heredoc "wikilink")
  - [variable math](variable_math "wikilink")
  - [reading in variables](reading_in_variables "wikilink") - User
    prompt