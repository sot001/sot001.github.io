`if `[`$var``   ``=``   ``*pattern1*`]($var_=_*pattern1* "wikilink")
`then`
`    echo "Do something"`
`fi`