Run this command to fix the backtick key so it doesn't require multiple
strikes.

    xmodmap -e 'keycode 49 = grave asciitilde'