  - [clearing down /boot when at
    100%](clearing_down_/boot_when_at_100% "wikilink")
  - [disable / enable services](disable_/_enable_services "wikilink")
  - [disable GUI on boot](disable_GUI_on_boot "wikilink")
  - [changing mac address](changing_mac_address "wikilink")
  - [apt-get](apt-get "wikilink")
  - [Hold or Exclude packages](Hold_or_Exclude_packages "wikilink")
  - [remount fileystem rw](remount_fileystem_rw "wikilink") - after
    disaster
  - [ubuntu 14.04 - removing top task
    bar](ubuntu_14.04_-_removing_top_task_bar "wikilink")
  - [dpkg](dpkg "wikilink") - working with .deb packages
  - [UFW](UFW "wikilink") - firewall
  - [visudo - change default
    editor](visudo_-_change_default_editor "wikilink")
  - [removing ssh keys from
    keyring](removing_ssh_keys_from_keyring "wikilink")
  - [have to hit backtick key several
    times](have_to_hit_backtick_key_several_times "wikilink")
  - [Ubuntu on Windows (WSL2)](Ubuntu_on_Windows_\(WSL2\) "wikilink")
  - [troubleshooting long boot
    times](troubleshooting_long_boot_times "wikilink")

Setup needed for new environment

  - install nextcloud - pull in ubuntu environment and
    personal_projects.
  - once netcloud is synced down, run
    \~/Nextcloud/personal-projects/scripts/workspace.sh (this script
    also exists in dotfiles repo)

that should get most things installed.

## or

get the workspace script from the dotfiles repo and run that

next, for work and things you'll need to checkout the appropriate branch
in dotfiles

[Category: linux](Category:_linux "wikilink")