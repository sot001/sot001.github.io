[category: linux](category:_linux "wikilink") [category:
security](category:_security "wikilink")

use *update-alternatives --config editor*