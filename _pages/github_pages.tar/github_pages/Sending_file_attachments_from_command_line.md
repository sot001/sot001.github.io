use mutt;

`echo "This is the body of the email" | mutt -a the_attachment.file -s "the subject of the email" the.recipient@a.mailaddress`