to run mysql in batch mode, and return results without the columns, use
the following switches;

` mysql -h servermysql -sN -e 'show databases'`