[adding swap file](adding_swap_file "wikilink")

[mail attachment](mail_attachment "wikilink")

[Run command as different
user](Run_command_as_different_user "wikilink")