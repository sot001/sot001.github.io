to allow access, the following ports need opening;

`9000                       ALLOW       1.22.333.44`
`3483                       ALLOW       1.22.333.44`