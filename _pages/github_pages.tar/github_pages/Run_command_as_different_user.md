`su - `<username>` -s `<shell>` -c "`<command>`"`

eg;

`su - www-data -s /bin/bash -c "/usr/bin/youtube-downloader.sh"`

[Category: linux](Category:_linux "wikilink") [Category:
bash](Category:_bash "wikilink")