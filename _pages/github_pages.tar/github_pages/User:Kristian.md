<http://wakeup.viacom.com/WebWakeUp/Registered.aspx>

Bitlocker Password:

`       674619-373945-617342-266134-189552-225720-656887-325809`

<http://theevilbit.blogspot.co.uk/2014/04/using-dislocker-to-mount-bitlocker.html>

<http://superuser.com/questions/376533/how-to-access-a-bitlocker-encrypted-drive-in-linux>