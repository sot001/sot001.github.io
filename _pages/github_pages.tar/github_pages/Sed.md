  - [sed: find and replace in
    file](sed:_find_and_replace_in_file "wikilink")
  - [sed: remove comments and blank
    lines](sed:_remove_comments_and_blank_lines "wikilink")
  - [sed: append text to a line with a
    pattern](sed:_append_text_to_a_line_with_a_pattern "wikilink")