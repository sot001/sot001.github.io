1.  REDIRECT [Ffmpeg - Record online
    stream](Ffmpeg_-_Record_online_stream "wikilink")