  - [mysql batch mode](mysql_batch_mode "wikilink")
  - [dump and load many dbs](dump_and_load_many_dbs "wikilink")
  - [mysql log search script](mysql_log_search_script "wikilink")
  - [mysql backup script](mysql_backup_script "wikilink")
  - [mysql keeping your password
    safe](mysql_keeping_your_password_safe "wikilink")
  - [mysql resetting root
    password](mysql_resetting_root_password "wikilink")
  - [mysql clearing logs](mysql_clearing_logs "wikilink")
  - [galera forcing percona node to
    resync](galera_forcing_percona_node_to_resync "wikilink")
  - [galera troubleshooting](galera_troubleshooting "wikilink")
  - [mysql replication with
    innobackupex](mysql_replication_with_innobackupex "wikilink")