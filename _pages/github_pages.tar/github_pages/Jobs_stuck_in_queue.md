check the hostname in the jobqueue table;

    select * from jobqueue;

Some may have the shortened version of the hostname or a different
version that which works. check the ones that have a completed status
(272) and adjust accordingly