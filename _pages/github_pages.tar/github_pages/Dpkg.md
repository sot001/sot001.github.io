    dpkg -i <package>

install a package

    dpkg -l

lists all installed packages

    dpkg -r <package as listed by dpkg -l>

removes a package