the favourites file (favorites.opml) is held in the
/var/lib/squeezeboxserver/prefs folder