    openssl enc -e -bf-cbc -in <FILE>.tar.gz -out <FILE>.tar.gz.enc
    openssl enc -d -bf-cbc -in <FILE>.tar.gz.enc -out <FILE>.tar.gz

[Category:Security](Category:Security "wikilink")