(vim)

  - [prepending text](prepending_text "wikilink")
  - [remove whitespace](remove_whitespace "wikilink")
  - [replacing comma with
    newline](replacing_comma_with_newline "wikilink")
  - [vim - sort](vim_-_sort "wikilink")