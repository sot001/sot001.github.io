  - **Centos7** check uWSGI is running. The ini file may have been
    overwritten by and update to a Centos 6 ini file, with daemonize in
    it. remove that and restart