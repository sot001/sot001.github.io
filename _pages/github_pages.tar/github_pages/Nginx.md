[category: nginx](category:_nginx "wikilink")

## Install

(based around [this](https://www.mythtv.org/wiki/MythWeb_on_Nginx))
after adding the official repo via
[these](https://www.nginx.com/resources/wiki/start/topics/tutorials/install/)
instructions

`apt-get install nginx`
`apt-get install php5-fpm`
`apt-get install fcgiwrap # for cgi`
`cp /usr/share/doc/fcgiwrap/examples/nginx.conf /etc/nginx/fcgiwrap.conf # to keep a copy`