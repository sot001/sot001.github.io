log out of lubuntu (log out, don't just restart if auto-login is
installed) and then change your session to xfce. this shifts everything
down and removes the top bar