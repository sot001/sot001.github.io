## running occ commands

run as www-data

    eg.
    sudo -u www-data php /usr/share/nginx/nextcloud/occ db:add-missing-indices