  - Beach House 621.5, 63.0, 1246.5
  - Village 519 64 1067
  - big village - hole in the middle -722 69 760
  - Big House - 510 64 1086
  - alternate nether portal to blaze spawner - -2451 67 1703

#### Track to the jungle

1.  House 1 ![<File:Journey1.PNG>](Journey1.PNG "File:Journey1.PNG") X
    994 Z 60
2.  House 2 ![<File:Journey2.PNG>](Journey2.PNG "File:Journey2.PNG") X
    750 Y 73 Z -337
3.  tree house (jungle) X 921 Y 64 Z -3909