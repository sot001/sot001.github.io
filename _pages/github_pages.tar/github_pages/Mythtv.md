Stuff related to myth here

  - [Compile tbs6922](Compile_tbs6922 "wikilink")
  - [query for getting recorded signed
    programs](query_for_getting_recorded_signed_programs "wikilink")
  - [tuning dvb-s uk](tuning_dvb-s_uk "wikilink")
  - [channel info](channel_info "wikilink")
  - [importing videos via
    get_iplayer](importing_videos_via_get_iplayer "wikilink")
  - [HDMI sound with Zotac Ion](HDMI_sound_with_Zotac_Ion "wikilink")
  - [Ubuntu 14.04 - removing top task
    bar](Ubuntu_14.04_-_removing_top_task_bar "wikilink")
  - [videos zoomed in, cropped on
    edges](videos_zoomed_in,_cropped_on_edges "wikilink")
  - [adding custom filters to mythweb recordings
    page](adding_custom_filters_to_mythweb_recordings_page "wikilink")
  - [changing default start-early, end-late
    settings](changing_default_start-early,_end-late_settings "wikilink")
  - [jobs stuck in queue](jobs_stuck_in_queue "wikilink")