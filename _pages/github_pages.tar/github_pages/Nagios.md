  - [Nagios - acknowledging alerts via
    email](Nagios_-_acknowledging_alerts_via_email "wikilink")
  - [Nagios - checking Quorum
    drives](Nagios_-_checking_Quorum_drives "wikilink")