on xubuntu the keyring program is called seahorse. run that from a
terminal and you'll be able to select which keys to forget.