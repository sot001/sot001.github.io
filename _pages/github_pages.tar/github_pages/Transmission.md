To enable the daemon, set the following variable

`ENABLE_DAEMON=1`

in the file /etc/default/transmission-daemon and then it should start.