  - [ffmpeg - trim a video](ffmpeg_-_trim_a_video "wikilink")
  - [ffmpeg - Record online
    stream](ffmpeg_-_Record_online_stream "wikilink")
  - [ffmpeg - Extract audio from video and
    tag](ffmpeg_-_Extract_audio_from_video_and_tag "wikilink")
  - [ffmpeg - trim audio](ffmpeg_-_trim_audio "wikilink")