#### ingredients

  - 1 tbsp olive oil
  - 8 chipolatas, meat squeezed out and rolled into balls
  - 3 eggs
  - 50g parmesan, grated, plus extra to serve (optional)
  - 300g spaghetti
  - 1 head broccoli, broken into small florets
  - 2 garlic cloves, crushed

#### method

1.  In a large pan, heat the oil and cook the sausageballs until golden,
    moving them around in the pan frequently. Meanwhile, mix together
    the eggs, cheese and some seasoning with a fork in a jug.
2.  Cook the pasta following pack instructions. Add the broccoli for the
    final 3 mins, then drain, reserving a cup of the cooking water.
3.  Add the garlic to the sausageballs and cook for a couple mins more,
    being careful the garlic doesn’t brown. Remove the pan from the
    heat.
4.  Add the pasta and broccoli to the sausage pan. Toss everything
    together, then add the egg mixture. Stir the sauce through the pasta
    for 1-2 mins. The heat from the pan will cook the sauce – if it is
    too thick, use a little of the reserved cooking water to thin it.
    Divide between pasta bowls and serve with extra Parmesan, if you
    like.