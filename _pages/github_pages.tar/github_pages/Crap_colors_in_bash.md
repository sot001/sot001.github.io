run 'unset [LS_COLORS](LS_COLORS "wikilink")' from the terminal to
remove the annoying blue in putty.

<small>colors putty colours color colour</small>