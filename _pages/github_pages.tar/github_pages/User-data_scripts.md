To retrieve user data from within a running instance, use the following
URI.

`curl `<http://169.254.169.254/latest/user-data>