`fmpeg -i orion.mov -strict -2 -ss 00:04:53 -t 57 best_fiends.mov`

\- strict -2 means use h264 experimental driver