Difference beteeen two numeric variables;

    DELETEDAYS=14
    WARNDAYS=7
    DAYSDIFF=$(($DELETEDAYS - $WARNDAYS))

Other mathematic operators can be used: \* / + -