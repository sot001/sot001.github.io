#### ingredients

  - 500g grated carrot
  - 400g sugar
  - 1 orange juice and zest
  - 1 lemon juice and zest
  - 500ml of water

#### method

1.  grate carrot add to sugar, orange, lemon juice and zest and leave
    overnight, or at least 6 hours., this releases the juice from the
    carrots.
2.  the next day add the water bring to the boil and simmer for one hour
    with the lid on.
3.  if too much liquid simmer with lid off until you get a nice syrup or
    thickened slightly.

### notes

  - forgot to steep carrots in juice and sugar so maybe thats why it
    broke, but it was too carroty and sweet. Also didn't set. Next,
    halve the carrots and add another Orange.

Trying...

  - 250g carrot
  - 2 large oranges juice and zest
  - 1 lemon juice and zest
  - steeping it overnight in the fridge